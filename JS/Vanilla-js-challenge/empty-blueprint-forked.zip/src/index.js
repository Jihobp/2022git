const bd = document.querySelector("body");
//const text = document.querySelector("Hello");
function Resize() {
  const size = window.innerWidth;
  bd.style.color = "white";
  if (size >= 800) {
    bd.style.backgroundColor = "tomato";
  } else if (size < 700 && size > 400) {
    bd.style.backgroundColor = "purple";
  } else {
    bd.style.backgroundColor = "red";
  }
}
window.addEventListener("resize", Resize);

// function sayHello(){
//   console.log("Hello!");
// }
